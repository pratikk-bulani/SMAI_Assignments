#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings

from rdkit import Chem

warnings.filterwarnings("ignore")

from gensim.models import word2vec
from mol2vec.features import mol2alt_sentence, mol2sentence, MolSentence, DfVec, sentences2vec
from gensim.models import word2vec

from sklearn.linear_model import RidgeCV
from sklearn.model_selection import train_test_split

from keras.layers import Dense, Activation, Dropout, BatchNormalization, Input
from keras.models import Sequential, Model
from keras import optimizers, regularizers, initializers
from keras.callbacks import ModelCheckpoint, Callback
from keras import backend as K
from keras.optimizers import Adam

from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


# In[2]:


class covid:
    def __init__(self, file, model_name='ridge'):
        self.file = file
        
        df = pd.read_csv(self.file)
        df['mol'] = df['SMILES sequence'].apply(lambda x : Chem.MolFromSmiles(x))
        
        model = word2vec.Word2Vec.load('model_300dim.pkl')
        target = df['Binding Affinity']
        df = df.drop(columns=['Binding Affinity'])
        self.Y = target.values

        df['sentence'] = df.apply(lambda x: MolSentence(mol2alt_sentence(x['mol'], 1)), axis=1)
        df['mol2vec'] = [DfVec(x) for x in sentences2vec(df['sentence'], model, unseen='UNK')]
        
        self.X = np.array([x.vec for x in df['mol2vec']])
        
        standard_scaler = StandardScaler()
        self.X_scale = standard_scaler.fit_transform(self.X)

        self.train_x, self.test_x, self.train_y, self.test_y = train_test_split(self.X_scale,
                                                            self.Y,
                                                            test_size=0.33,
                                                            random_state=42)
        
        self.model_name = model_name
        if self.model_name == 'ridge':
            self.model = RidgeCV(cv=5)
            print(self.model)
            
        if self.model_name =='mlp':
            DROPRATE = 0.5
            self.model = Sequential()
            self.model.add(Dense(128, input_dim = self.X.shape[1]))
            self.model.add(BatchNormalization())
            self.model.add(Activation('tanh'))
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(256))
            self.model.add(Activation('tanh'))
            self.model.add(BatchNormalization())
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(512))
            self.model.add(Activation('tanh'))
            self.model.add(BatchNormalization())
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(256))
            self.model.add(Activation('tanh'))
            self.model.add(BatchNormalization())
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(128))
            self.model.add(Activation('tanh'))
            self.model.add(BatchNormalization())
            self.model.add(Dropout(rate = DROPRATE))


            self.model.add(Dense(64))
            self.model.add(BatchNormalization())
            self.model.add(Activation('tanh'))
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(32))
            self.model.add(BatchNormalization())
            self.model.add(Activation('tanh'))
            self.model.add(Dropout(rate = DROPRATE))

            self.model.add(Dense(1, activation = None))
            
            print('Model\n',self.model.summary())
            self.model.compile(loss='mae', optimizer='adam', metrics=['mse'])
        
        if self.model_name == 'svc':
            self.model = SVR(epsilon=1, C=5)
            print(self.model)
        
    def fit(self):
        if self.model_name == 'ridge':
            self.model.fit(self.train_x, self.train_y)
            preds = self.model.predict(self.test_x)
            
            print('Val MAE %f VAL MSE %f'%(mean_absolute_error(preds, self.test_y),
                                           mean_squared_error(preds, self.test_y)))
        if self.model_name == 'mlp':
            self.history = self.model.fit(
                                            self.X_scale,
                                            self.Y,
                                            validation_split=.3, 
                                            epochs=500,
                                            batch_size=256
                                          )
        if self.model_name == 'svc':
            self.model.fit(self.train_x, self.train_y)
            
            preds = self.model.predict(self.test_x)
            
            print('Val MAE %f VAL MSE %f'%(mean_absolute_error(preds, self.test_y),
                                           mean_squared_error(preds, self.test_y)))
            
    def predict(self, file):
        df = pd.read_csv(file)
        df['mol'] = df['SMILES sequence'].apply(lambda x : Chem.MolFromSmiles(x))
        
        model = word2vec.Word2Vec.load('model_300dim.pkl')
        

        df['sentence'] = df.apply(lambda x: MolSentence(mol2alt_sentence(x['mol'], 1)), axis=1)
        df['mol2vec'] = [DfVec(x) for x in sentences2vec(df['sentence'], model, unseen='UNK')]
        
        test_X = np.array([x.vec for x in df['mol2vec']])
        
        preds = self.model.predict(test_X)
        
        df['Binding Affinity'] = preds
        
        df.drop(columns=['mol', 'mol2vec', 'sentence'], inplace=True)
        
        df.to_csv('%s_submission.csv'%self.model_name, index=False)
        
        return        


# In[3]:


covid1 = covid('./22bba507-efcf-4af0-b9d0-f26193605457_train.csv')
covid1.fit()


# In[4]:


covid1.predict('./q3test.csv')


# In[5]:


covid1 = covid('./22bba507-efcf-4af0-b9d0-f26193605457_train.csv', model_name='svc')
covid1.fit()


# In[6]:


covid1.predict('./q3test.csv')


# In[7]:


covid2 = covid('./22bba507-efcf-4af0-b9d0-f26193605457_train.csv', model_name='mlp')


# In[8]:


covid2.fit()


# In[11]:


covid2.predict('./q3test.csv')


# In[12]:


covid2.model.save_weights("model.h5")


# In[ ]:




