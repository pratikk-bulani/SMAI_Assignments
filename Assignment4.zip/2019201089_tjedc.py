#!/usr/bin/env python
# coding: utf-8

# In[1]:


from torchvision import transforms
import torchvision
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
from PIL import Image
import glob

class image_loader(Dataset):
    def __init__(self, transforms_=None, **args):
        
        self.transforms = transforms.Compose(transforms_)
        
        try:
            self.path = args['path']
        except:
            print('path not provided')
            raise Exception
        
        self.mode = 'train' if 'mode' not in args.keys() else 'val'
        self.mode = 'test' if 'mode' in args.keys() and args['mode'] == 'test' else self.mode
        
        self.label_data = pd.read_csv(args['labels'] if 'labels' in args.keys() else glob.glob('./*_train.csv'))
        
        
        
        val_split = int(len(self.label_data) * 0.2) if self.mode != 'test' and not args['no_val'] else len(self.label_data)
        
        np.random.seed(100)
        self.label_data = self.label_data.iloc[np.random.permutation(len(self.label_data))] if self.mode != 'test' else self.label_data
        
        self.label_data = self.label_data[:-val_split] if self.mode == 'train' and not args['no_val'] else self.label_data[-val_split:]
        
    
    def __getitem__(self, index):
        label = None
        if self.mode == 'train' or self.mode == 'val':
            img_name, label = self.label_data.iloc[index]['image_file'], self.label_data.iloc[index]['emotion']
        
        elif self.mode == 'test':
            img_name = self.label_data.iloc[index]['image_file']
        
        img = Image.open(self.path + '/%s.jpg'%(img_name))
        
        img = self.transforms(img)
        
        if self.mode == 'test':
            return img
        else:
            return img, label
    
    def __len__(self):
        return len(self.label_data)


# In[2]:


from torch import nn
from torch import optim
from torch.autograd import Variable
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torchvision import models

# writer = SummaryWriter('./log/tomandjerry')

class emotion_detector(nn.Module):
    
    def __init__(self, pretrained=False):
        super().__init__()
        
        def down_sample(normalize=True, activation=True, max_pool=False, in_channels=None, out_channels=None, kernel_size=(4,4), stride=None):
            layers = list()
            
            args = {
                        'in_channels':  in_channels,
                        'out_channels': out_channels,
                        'kernel_size':  kernel_size,
                        'stride': stride 
                   }
            
                        
            layers.append(nn.Conv2d(**args))
            
            if normalize:
                layers.append(nn.BatchNorm2d(args['out_channels']))
            
            if activation:
                layers.append(nn.LeakyReLU(.2))
            
            if max_pool:
                layers.append(nn.MaxPool2d(kernel_size=(2,2)))
            
            return layers
        
        def get_layers(layer_config_list):
            layers = list()
            
            for layer_config in layer_config_list:
                layers += down_sample(**layer_config)
            
            return layers
        
        def config_layer(activation=True, normalize=True, max_pool=False, in_channels=None, out_channels=None, kernel_size=None, stride=None):
            return locals()
        
        # --- network config
        
        self.network = list()
        
        class Flatten(nn.Module):
            def forward(self, x):
                x = x.view(x.size()[0], -1)
                return x
            
        self.network.append(config_layer(
                                            in_channels=3, 
                                            out_channels=64, 
                                            kernel_size=(4,4),
                                            stride=(2, 2),
                                            normalize=False,
                                            max_pool=True
                                        )
                           )
        self.network.append(config_layer(
                                            in_channels=64, 
                                            out_channels=128, 
                                            kernel_size=(4,4),
                                            stride=(2, 2),
                                            max_pool=True
                                        )
                           )
        
        self.network.append(config_layer(
                                            in_channels=128, 
                                            out_channels=256, 
                                            kernel_size=(4,4),
                                            stride=(2, 2),
                                            max_pool=True
                                        )
                           )
        if pretrained:
            self.pretrained_flag=True
            self.pretrained = models.resnet152(pretrained=True)
            # Freeze the parameters
            for params in self.pretrained.parameters():
                params.requires_grad = False
            
        self.model = nn.Sequential(
                                    *get_layers(self.network),
                                    Flatten(),
                                    #  FC -- Layers
                                    nn.Linear(512, 256),
                                    nn.Dropout(.25),
                                    nn.Linear(256, 5),
                                    nn.Softmax(dim=1)
                                  )
                                    
    
    def forward(self, img):
        output = img
        if self.pretrained_flag:
            output = self.pretrained(output)
        output = self.model(output)
        return output
            


# In[3]:


import torch
ed = emotion_detector()
CEloss = nn.BCELoss()
if torch.cuda.is_available():
    ed.cuda()
    CEloss.cuda()


# In[4]:


transforms_ =   [
                    transforms.Resize(128),
                    transforms.ToTensor(),
                    transforms.Normalize((.5, .5, .5), (.5, .5, .5))
                ]
train_data_loader = DataLoader(
                                image_loader(path='./7632a1cf-95f9-4d1c-bc5b-9436699bdae2_train/ntrain' , 
                                             labels='./db5fcca9-f52b-42a9-87be-26f77b6f9d97_train.csv', 
                                             transforms_=transforms_,
                                             no_val=True),
                                batch_size=64,
                                shuffle=True,
                                num_workers=0
                              )
val_data_loader = DataLoader(
                                image_loader(path='./7632a1cf-95f9-4d1c-bc5b-9436699bdae2_train/ntrain' , 
                                             labels='./db5fcca9-f52b-42a9-87be-26f77b6f9d97_train.csv',
                                             transforms_=transforms_,
                                             mode='val',
                                             no_val=False),
                                batch_size=64,
                                shuffle=True,
                                num_workers=0
                              )


# In[5]:


optimizer = optim.Adam(ed.model.parameters(), lr=.0002)


# In[6]:


from tqdm import tqdm 
epochs = 35
for epoch in range(epochs+1):
    
    with tqdm(total=len(train_data_loader), desc='Epoch {:<7d} Trained Batches'.format(epoch)) as progress:
        num_imgs = 0
        epoch_loss = 0
        correct = 0
        for i, (imgs, labels) in enumerate(train_data_loader):
            imgs = Variable(imgs.type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor), requires_grad=False)
            labels= Variable(labels.type(torch.cuda.LongTensor if torch.cuda.is_available() else torch.FloatTensor), requires_grad=False)
            one_hot_labels = nn.functional.one_hot(labels, num_classes=5)
                       
            # Clear Gradient accumulation of rev Step
            optimizer.zero_grad()
            
            preds = ed(imgs)

            _, pred_labels = torch.max(preds.data, 1)
            
            correct += (pred_labels == labels).sum().item()
            batch_loss = CEloss(preds, one_hot_labels.float())
            
            # Backprop and Wt updation
            batch_loss.backward()
            optimizer.step()

            epoch_loss += batch_loss.item() * imgs.shape[0]
            num_imgs += imgs.shape[0]
            
            progress.update()
            progress.set_postfix_str(
                                        s='Loss %f Accuracy %f'%(epoch_loss/num_imgs, correct/num_imgs),
                                        refresh=True
                                    )

#     with tqdm(total=len(val_data_loader), desc='Epoch {:<7d} Tested Batches'.format(epoch)) as progress:
#         num_imgs = 0
#         epoch_loss = 0
#         correct = 0
#         for i, (imgs, labels) in enumerate(val_data_loader):
#             imgs = Variable(imgs.type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor))
#             labels= Variable(labels.type(torch.cuda.LongTensor if torch.cuda.is_available() else torch.FloatTensor))
#             one_hot_labels = nn.functional.one_hot(labels, num_classes=5)

#             preds = ed(imgs)

#             _, pred_labels = torch.max(preds.data, 1)

#             correct += (pred_labels == labels).sum().item()

#             batch_loss = CEloss(preds, one_hot_labels.float())

#             epoch_loss += batch_loss.item() * imgs.shape[0]
#             num_imgs += imgs.shape[0]
            
#             progress.update()
#             progress.set_postfix_str(
#                                         s='Loss %f Accuracy %f'%(epoch_loss/num_imgs, correct/num_imgs),
#                                         refresh=True
#                                     )
            


# In[7]:


torch.save({
             'epoch' : epoch,
             'emotion_detector_state_dict' : ed.state_dict(),
             'loss_state_dict': CEloss.state_dict(),
             'optimizer_state_dict':optimizer.state_dict(),
            }, 
            'emotion_detector.pt'
           )


# In[5]:


test_data_loader =  DataLoader(
                                image_loader(path='./test/test' , 
                                             labels='test.csv',
                                             transforms_=transforms_,
                                             mode='test'
                                            ),
                                batch_size=64
                              )


# In[10]:


import torch
from tqdm import tqdm
ed = emotion_detector()

ed.load_state_dict(torch.load('emotion_detector.pt')['emotion_detector_state_dict'])
ed.cuda()


# In[11]:


predictions = list()
with tqdm(total=len(test_data_loader), desc='Tested Batches') as progress:
    for i, imgs in enumerate(test_data_loader):
       
        imgs = Variable(imgs.type(torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor), requires_grad=False)

        preds = ed(imgs)

        _, pred_labels = torch.max(preds.data, 1)
        predictions += list(pred_labels.data)

        progress.update()


# In[12]:


predictions = [i.item() for i in predictions]


# In[13]:


output_csv = pd.DataFrame({'emotion':predictions}, columns=['emotion'])
output_csv.to_csv('output.csv', index=None)


# In[12]:


print('model\n', ed)


# In[ ]:




