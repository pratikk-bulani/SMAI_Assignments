import os
import cv2
import sys
import glob
import numpy as np
import random
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
# from google.colab.patches import cv2_imshow


def sigmoid(x):
    sig = 1 / (1 + np.exp(-x))
    return sig

def cross_entropy_loss(y, prob):
    loss = (-y*np.log(prob + 0.00000001) -(1 - y)*np.log(1- prob + 0.00000001)).mean()
    return loss

def derivative_cross_entropy_loss(prob, y, act):
    L_dash = np.matmul(act.transpose(), (prob - y)) / y.shape[0]
    return L_dash

class log_regression:
    def __init__(self, train_file, test_file, learning_rate = 0.01, epochs = 4000):
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.data = self.images = self.labels = None
        self.test_x = self.train_x = self.test_y = self.test_x = None

        self.pcs = 400

        train_files, train_labels = [], []
        with open(train_file, 'r') as f:
            while True:
                l = f.readline()
                if not l:
                    break
                train_files.append(l.split()[0].strip())
                train_labels.append(l.split()[1].strip())
        

        self.train_x = np.array([cv2.imread(file, 0).flatten() for file in train_files])
        self.train_y = np.array(train_labels)
        self.unique_labels = np.unique(self.train_y)

        self.label_dict = dict()
        for i,j in enumerate(self.unique_labels):
            self.label_dict[j] = i

        for i in self.label_dict:
            self.train_y[np.where(self.train_y == i)] = self.label_dict[i]
        
        self.train_y = self.train_y.astype(np.int16)
        self.unique_labels = np.unique(self.train_y)

        # print(self.train_y)
        # print(train_files)
        # print(self.train_x.shape)
        # print(self.train_y)
        # print(self.unique_labels)

        test_files = []
        with open(test_file, 'r') as f:
            while True:
                l = f.readline()
                if not l:
                    break
                test_files.append(l.strip())
        #comment for now
        self.test_x = np.array([cv2.imread(file, 0).flatten() for file in test_files])

        # print(self.test_x.shape)
        # self.train_x, self.test_x, self.train_y, self.test_y = train_test_split(self.train_x, self.train_y, test_size=0.1)

    def get_mean_face(self):
        return self.train_x.mean(axis=0)

    def normalize(self):
        self.normalized = (self.train_x - self.mean_face.reshape(1, -1))
        std = np.std(self.normalized, axis = 0)
        self.normalized = self.normalized / std

    def get_eigen_vectors(self):
        self.eigen_values, self.eigen_vectors = np.linalg.eig(self.cov_matrix)

        order = self.eigen_values.argsort()[::-1]
        self.eigen_values, self.eigen_vectors  = self.eigen_values[order], self.eigen_vectors[:,order]

    def train(self):
        self.mean_face = self.get_mean_face()

        self.normalize()

        self.cov_matrix = np.matmul(self.normalized, self.normalized.T)/self.normalized.shape[0]

        self.get_eigen_vectors()

        self.final_pcs = self.eigen_vectors[:, :self.pcs]

        self.projected = np.matmul(self.normalized.transpose(), self.final_pcs)
        norm = np.linalg.norm(self.projected, axis = 0)
        self.projected = self.projected / norm

        self.images_reduced = np.matmul(self.normalized, self.projected)
        self.images_reduced = np.append(self.images_reduced, np.ones((len(self.images_reduced), 1)), axis = 1)

        self.weights_labels = np.random.normal(size=(len(self.unique_labels), self.images_reduced.shape[1])).astype(np.float128)

        label_loss = np.zeros((len(self.unique_labels), self.epochs))

        for label_index in range(len(self.unique_labels)):
            train_labels_new = np.zeros((self.train_y.shape)); train_labels_new[self.train_y == self.unique_labels[label_index]] = 1
            for epoch in range(self.epochs):
                non_linearity = sigmoid(np.matmul(self.images_reduced, self.weights_labels[label_index, :]))
                label_loss[label_index][epoch] = cross_entropy_loss(train_labels_new, non_linearity)
                self.weights_labels[label_index, :] = self.weights_labels[label_index, :] - self.learning_rate * derivative_cross_entropy_loss(non_linearity.reshape(-1, 1), train_labels_new.reshape(-1, 1), self.images_reduced).flatten()

    def predict(self):

        self.normalized_test_x = (self.test_x - self.mean_face.reshape(1, -1))
        std = np.std(self.normalized_test_x, axis = 0)
        self.normalized_test_x = self.normalized_test_x / std

        reduced_test_x = np.matmul(self.normalized_test_x, self.projected)

        reduced_test_x = np.append(reduced_test_x, np.ones((len(reduced_test_x), 1)), axis = 1)

        predicted_outputs = np.zeros(len(self.test_x))

        for i in range(len(reduced_test_x)):
            predicted_outputs[i] = self.unique_labels[np.matmul(reduced_test_x[i, :].reshape(1, -1), self.weights_labels.transpose()).flatten().argmax()]

        
        predicted_outputs = predicted_outputs.astype(np.int16)
        
        # print(predicted_outputs)

        final = np.zeros(len(self.test_x)).astype(np.object)
        
        for i in self.label_dict:
            final[np.where(predicted_outputs == self.label_dict[i])] = i

        print(*final,sep='\n')

        # print(accuracy_score(predicted_outputs, self.test_y))  

model = log_regression(sys.argv[1], sys.argv[2])
model.train()
model.predict()