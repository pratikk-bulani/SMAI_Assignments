

from keras.datasets import mnist
from keras.utils import to_categorical
from keras.layers import Dense, Conv2D, MaxPooling2D, Dropout, Flatten
from keras.models import Sequential
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import OneHotEncoder
import numpy as np

import os
import sys
import tensorflow as tf
from mnist import MNIST

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

stderr = sys.stderr
sys.stderr = open(os.devnull, 'w')
sys.stderr = stderr


# ( train_x, train_y ), (test_x, test_y) = mnist.load_data()
mdata  =  MNIST(sys.argv[1])
mdata.gz = True
train_x, train_y = mdata.load_training()
test_x, test_y = mdata.load_testing()

encoder = OneHotEncoder()

train_x, train_y = np.array(train_x), np.array(train_y)
test_x, test_y = np.array(test_x), np.array(test_y)

train_x = train_x.reshape(train_x.shape[0], 28, 28, 1)/255
train_y = encoder.fit_transform(train_y.reshape(-1,1)).toarray()
# train_y = to_categorical(train_y, num_classes=10)

test_x = test_x.reshape(test_x.shape[0], 28, 28, 1)/255
test_y = encoder.fit_transform(test_y.reshape(-1,1)).toarray()

model = Sequential()
model.add(Conv2D(28, kernel_size=(3, 3), activation='relu',input_shape=(28, 28, 1)))
model.add(Conv2D(56, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax'))


model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

history = model.fit(train_x, train_y, validation_split=.2, epochs=20, batch_size=64, verbose=0)

pred = model.predict(test_x)
for i in list(encoder.inverse_transform(pred).reshape(-1)):
    print(list(encoder.inverse_transform(pred).reshape(-1))[i])
# print(accuracy_score(np.argmax(test_y, axis=1), pred))