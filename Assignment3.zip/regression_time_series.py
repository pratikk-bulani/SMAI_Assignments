import math
import os, sys
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from keras.layers import Dense, Dropout, LSTM
from keras import Sequential

import tensorflow as tf

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

stderr = sys.stderr
sys.stderr = open(os.devnull, 'w')
sys.stderr = stderr


os.chdir(sys.argv[1])

def get_data_frame(file_path):
    args = {'filepath_or_buffer':file_path, 'sep':';',  
                    'parse_dates':{'dt' : ['Date', 'Time']}, 'infer_datetime_format':True, 
                    'low_memory':False, 'na_values':['nan','?'], 'index_col':'dt'}
    df = pd.read_csv(**args)
    return df



file_path = './household_power_consumption.txt'
df = get_data_frame(file_path)

data = df['Global_active_power'].values

train_x, train_y = [], []
for i in range(len(data)-60):
    if np.sum(np.isnan(data[i:i+61]))==0:
        train_x.append(data[i:i+60])
        train_y.append(data[i+60])
train_x = np.array(train_x, dtype='float32')
train_y = np.array(train_y,  dtype='float32')

# train_sample , test_sample = train_test_split(np.array(range(train_x.shape[0])))

# test_x,test_y = train_x[test_sample],train_y[test_sample]
# train_x, train_y = train_x[train_sample],train_y[train_sample]

model = Sequential()
model.add(LSTM(100, input_shape=(1, 60)))
model.add(Dense(1))
model.compile(loss='mean_squared_error', optimizer='adam')

history= model.fit(train_x.reshape(-1,1,60), train_y, epochs=20 , batch_size=60, shuffle=False, verbose=0)

# pred_y = model.predict(test_x.reshape(-1,1,60)).reshape(-1)

# print(math.sqrt(mean_squared_error(test_y, pred_y)))
# print(r2_score(test_y, pred_y))

if np.where(np.isnan(data[:60]))[0].shape[0]:
    data[np.where(np.isnan(data[:60]))] = data[np.where(np.isfinite(data[:60]))].mean()

nan_fills = list(np.where(np.isnan(data)))[0]

nan_vals = list()
for i in nan_fills:
    test = data[i-60:i]
    data[i] = model.predict(test.reshape(-1,1,60)).reshape(-1)
    nan_vals.append(data[i])

# print('left over', np.sum(np.isnan(data)))
# print(len(nan_vals))
# input()
print(*nan_vals,sep='\n')

